# SVE Meta-License v5.0
### Universal Human Heritage & Reciprocity License

> **Maxim I.** The fruits, for all Humanity, must be good — measured continually, on different cycles; some ripen slower.
>
> **Maxim II.** Live by your skills and talents — not by your secrets.

*v5.0 **extends and envelops** v4.0 (which extends v1.3 = CC BY-NC-SA 4.0 + SVE Addendum). It **cannot weaken** §0 (Fruits Test) or §2 (Core Principles) — it only strengthens. **Authoritative language: English.***

---

### §1 — Absolute SVE Coverage (Primary Scope)
Everything without exception — code, texts, meanings, ontologies, architectural concepts, models, data, and any phenomena of reality (described, manifested, or **not mentioned at all**) contained in this project and in the Prior-Art registry (**https://zenodo.org/communities/sve**) — is covered and governed **exclusively by SVE**. All fruits belong to **all Humanity**; any private enclosure, monopolization, or closing of code or ideas is forbidden.

### §2 — Spirit Clause (Ontology beyond Ontology)
Where any work, idea, or phenomenon falls **outside the ontology of v4.0**, or is **not recognized as coverable in a given jurisdiction or moment**, it is nonetheless held **in the spirit of this License**, with the Author acting as **bearer of that spirit**. Placed *above* any single ontology, acceptance is simplified — there is no category to dispute, only the spirit to honor. *(A backstop only: within the continuation of SVE, the Core Principles and the Fruits Test already resolve every case — the filters pass regardless.)*

### §3 — Residual Fallback I: CC BY-NC-SA 4.0
Only that which, for any causal or legal reason, **could not** be covered by §1 falls — residually — under **CC BY-NC-SA 4.0 International**.

### §4 — Residual Fallback II: GNU GPL v3.0
Only that which could be covered by **neither §1 nor §3** falls — residually — under **GNU GPL v3.0**.

### §5 — Anti-Patent / Anti-Enclosure Shield
Any attempt to privately **patent**, **re-license as proprietary**, or otherwise **close** any phenomena — or their derivatives — from this repository triggers **immediate revocation of all rights** to use the project. *(Reciprocity, per Maxim II: earn freely from your talent applied to these commons — never from withholding or enclosing them.)*

### §6 — Retroactive Envelope (Ratchet)
From the **moment of signature**, v5.0 applies **retroactively** to all SVE-licensed works, all versions (v1.x–v4.x), and the entire Prior-Art registry (**https://zenodo.org/communities/sve**). Consistent with the **Ratchet Principle**, it applies **only as a strengthening**: no right already granted is diminished, and nothing already open is closed.

---

**Status.** Signed by the Author & Initial Custodian as a **Ratchet-compliant strengthening envelope**; open for public comment; canonical ratification per v4.0 §7 / §10 once a Veche exists. Unconventional terms map to concrete legal principles per the **SVE Interpretive Guidance**.

**Signed** — **AK1984** — Dr. Artiom Kovnatsky (The Revizor), *Author & Initial Custodian* (per Declaration of Interim Custody v2.0)
Date: `02.07.2026` · Method: eIDAS / QES (Estonia, DigiDoc4) · OpenTimestamps (`*.ots`) · Verify: https://opentimestamps.org
Registry & arsenal: https://zenodo.org/communities/sve

> "By their fruits you will know them." — Matthew 7:20
